import os
import argparse
import zipfile
import tarfile
import rarfile
import py7zr
import streamlit as st
import sys
from openpyxl import load_workbook
import csv 
from openpyxl import Workbook
import time
import shutil
import concurrent.futures

# Records dictionary
packed_files = {}
unsupported_files = {}

unsupported_extensions = ['.gz','.wim']

# Function to decompress a ZIP file
def decompress_zip(file_path, destination_directory):
    try:
        with zipfile.ZipFile(file_path, 'r') as zip_ref:
            zip_ref.extractall(destination_directory)
            packed_files[file_path] = {
                'File Extension': 'zip'
            }
    except Exception as e:
        st.write("\n[-] Error",str(e))
        unsupported_files[file_path] = {
            'File Extension' : 'zip'
        }

# Function to decompress a RAR file
def decompress_rar(file_path, destination_directory):
    try:
        with rarfile.RarFile(file_path, "r") as rar_ref:
            rar_ref.extractall(destination_directory)
            packed_files[file_path] = {
                'File Extension': 'rar'
            }
    except Exception as e:
        st.write("\n[-] Error",str(e))
        unsupported_files[file_path] = {
            'File Extension' : 'rar'
        }

# Function to decompress a 7z file
def decompress_7z(file_path, destination_directory):
    try:
        with py7zr.SevenZipFile(file_path, "r") as seven_zip_ref:
            seven_zip_ref.extractall(destination_directory)
            packed_files[file_path] = {
                'File Extension': '7z'
            }
    except Exception as e:
        st.write("\n[-] Error",str(e))
        unsupported_files[file_path] = {
            'File Extension' : '7z'
        }

# Function to decompress a tar file
def decompress_tar(file_path, destination_directory):
    try:
        tar = tarfile.open(file_path)
        tar.extractall(destination_directory)
        tar.close()
        packed_files[file_path] = {
            'File Extension': 'tar'
            }
    except Exception as e:
        st.write("\n[-] Error",str(e))
        unsupported_files[file_path] = {
            'File Extension' : 'tar'
        }

# Function to recursively search for and decompress compressed files
def decompress_files(directory):
    count = 0
    compressed_files_count = 0
    for root, dirs, files in os.walk(directory):
        for file in files:
            count += 1
            file_path = os.path.join(root, file)
            file_extension = os.path.splitext(file)[1].lower()

            if file_extension == '.zip':
                compressed_files_count+=1
                st.write("[-] Decompressing file: ", file_path)
                destination_directory = os.path.splitext(file_path)[0]
                decompress_zip(file_path, destination_directory)
                decompress_files(destination_directory)

            if file_extension == '.7z':
                compressed_files_count+=1
                st.write("[-] Decompressing file: ", file_path)
                destination_directory = os.path.splitext(file_path)[0]
                decompress_7z(file_path, destination_directory)
                decompress_files(destination_directory)

            if file_extension == '.rar':
                compressed_files_count+=1
                st.write("[-] Decompressing file: ", file_path)
                destination_directory = os.path.splitext(file_path)[0]
                decompress_rar(file_path, destination_directory)
                decompress_files(destination_directory)

            if file_extension == '.tar':
                compressed_files_count+=1
                st.write("[-] Decompressing file: ", file_path)
                destination_directory = os.path.splitext(file_path)[0]
                decompress_tar(file_path, destination_directory)
                decompress_files(destination_directory)

            if file_extension in unsupported_extensions:
                compressed_files_count+=1
                st.write("\n[-] Moving unsupported file")
                unsupported_files[file_path] = {
                    'File Extension' : file_extension
                }
    return count, compressed_files_count

# Generate excel for the operations record
def generate_excel():
    wb = Workbook()

    matched_ws = wb.active

    # Sheet for unpacked files
    matched_ws.title = "Unpacked Files"
    matched_ws.append(['File_Path','File_Extension'])

    # Sheet for unsupported files
    unsupported_ws = wb.create_sheet(title="Unsupported Files")
    unsupported_ws.append(['File_Path','File_Extension'])

    for file_path,file_extension in packed_files.items():
        extension = file_extension['File Extension']
        if file_path:
            row_data = [file_path,extension]
            matched_ws.append(row_data)

    for file_path,file_extension in unsupported_files.items():
        extension = file_extension['File Extension']
        if file_path:
            row_data = [file_path,extension]
            unsupported_ws.append(row_data)

    return wb

# Main function
def main():
    input_directory = sys.argv[1]
    keyword_file = sys.argv[2]
    threshold = sys.argv[3]
    output_directory = sys.argv[4]

    if os.path.isdir(input_directory):
        num_threads = os.cpu_count()
        count, compressed_files_count = decompress_files(input_directory)
        st.write("[+] Unpacking complete")
        st.write("\n[+] Total files scanned: \t", count)
        st.write('\n[+] Total compressed files found: \t', compressed_files_count)
    else:
        st.write("[-] Invalid path provided")

    unpacker_directory_name = f"Unpacking Results"
    unsupported_files_directory_name = f"Unsupported Files"
    output_file_name = f"Unpacked_Files_Record.xlsx"

    unpacker_directory = os.path.join(output_directory, unpacker_directory_name)
    unsupported_files_directory = os.path.join(unpacker_directory, unsupported_files_directory_name)
    output_file_directory = os.path.join(unpacker_directory, output_file_name)

    st.write("\n[+] Creating directory to save results")
    time.sleep(5) # Sleep for 5 seconds
    os.makedirs(unpacker_directory, exist_ok=True)
    os.makedirs(unsupported_files_directory, exist_ok=True)

    wb = generate_excel()
    wb.save(output_file_directory)
    st.write("\n[+] Record file created: \t", output_file_directory)

    for file_path, info in unsupported_files.items():
        try:
            shutil.copy(file_path, os.path.join(unsupported_files_directory, os.path.basename(file_path)))
        except Exception as e:
            st.write("\n[-] Error: \t", str(e))

if __name__ == '__main__':
    main()