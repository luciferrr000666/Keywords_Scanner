import os
import sys
import shutil
import streamlit as st
import pandas as pd
from openpyxl import Workbook
import csv
from striprtf.striprtf import rtf_to_text
from docx import Document
from pptx import Presentation
import win32com.client
import docx2txt
from openpyxl import load_workbook

supported_extensions = ['.doc','.docx','.docm','.rtf','.pptx','.xlsx','.csv']
unsupported_extensions = ['.one','.dot','.wbk','.dotm','.docb','.wll','.wwl','.xls','.xlt','.xlm','.xll_','.xla_','.xla5','.xla8','.xlsm','.xltx','.xltm','.xlsb','.xla','.xlam','.xll','.xlw','.ppt','.pot','.pps','.ppa','.ppam','.pptm','.potx','.potm','.ppam','.ppsx','.ppsm','.sldx','.sldm','.pa','.accda','.accdb','.accde','.accdt','.accdr','.accdu','.mda','.mde','.ecf','.pub','.xps','.wps','.wpt','.odt','.fodt','.ods','.fods','.odp','.fodp','.odg','.fodg','.odf','.pages','.numbers']

matched_files = {}
other_office_files = {}
unreadable_files = {}


def rtf_read(file_path):
    content = ''
    try:
        with open(file_path) as infile:
            content = infile.read()
            text = rtf_to_text(content)
            return text
    except Exception as e:
        unreadable_files[file_path] = {
            'Size': os.path.getsize(file_path),
            'Extension': '.rtf',
            'Error': str(e)
        }
    return content


def docx_read(file_path):
    content = ''
    try:
        document = Document(file_path)
        for paragraph in document.paragraphs:
            content += paragraph.text
        return content
    except Exception as e:
        unreadable_files[file_path] = {
            'Size': os.path.getsize(file_path),
            'Extension': '.docx',
            'Error': str(e)
        }
    return content


def pptx_read(file_path):
    content = ''
    try:
        presentation = Presentation(file_path)
        for slide in presentation.slides:
            for shape in slide.shapes:
                if shape.has_text_frame:
                    for paragraph in shape.text_frame.paragraphs:
                        content += paragraph.text
        return content
    except Exception as e:
        unreadable_files[file_path] = {
            'Size': os.path.getsize(file_path),
            'Extension': '.pptx',
            'Error': str(e)
        }
    return content


def doc_read(file_path):
    content = ''
    word = win32com.client.Dispatch("Word.Application")
    word.visible = False
    try:
        doc = word.Documents.Open(file_path)
        content = doc.Content.Text
        doc.Close()
        word.Quit()
    except Exception as e:
        unreadable_files[file_path] = {
            'Size': os.path.getsize(file_path),
            'Extension': '.doc',
            'Error': str(e)
        }
    return content


def docm_read(file_path):
    content = ''
    try:
        document = docx2txt.process(file_path)
        content = document
    except Exception as e:
        unreadable_files[file_path] = {
            'Size': os.path.getsize(file_path),
            'Extension': '.docm',
            'Error': str(e)
        }
    return content


def xlsx_read(file_path):
    content = ''
    try:
        workbook = load_workbook(filename=file_path, read_only=True)
        sheet = workbook.active
        for row in sheet.iter_rows(values_only=True):
            for cell in row:
                if cell is not None:
                    cell_value = str(cell).lower()
                    content += cell_value
        return content
    except Exception as e:
        unreadable_files[file_path] = {
            'Size': os.path.getsize(file_path),
            'Extension': '.xlsx',
            'Error': str(e)
        }
    return content


def csv_read(file_path):
    content = ''
    try:
        with open(file_path, "r", encoding="utf-8", errors="ignore") as file:
            csv_file = csv.reader(file)
            for lines in csv_file:
                for cell in lines:
                    cell_value = cell.lower()
                    content += cell_value
        return content
    except Exception as e:
        unreadable_files[file_path] = {
            'Size': os.path.getsize(file_path),
            'Extension': '.csv',
            'Error': str(e)
        }
    return content


def search_office_files(input_directory, words):
    count = 0
    office_files_count = 0
    st.write("\n[+] Searching directory: \t", input_directory)
    for root, dir, files in os.walk(input_directory):
        for file in files:
            count += 1
            ext = os.path.splitext(file)[-1].lower()
            file_path = os.path.join(root, file)

            if ext in supported_extensions:
                office_files_count += 1
                if ext == '.csv':
                    content = csv_read(file_path)
                elif ext == '.xlsx':
                    content = xlsx_read(file_path)
                elif ext == '.doc':
                    content = doc_read(file_path)
                elif ext == '.docx':
                    content = docx_read(file_path)
                elif ext == '.docm':
                    content = docm_read(file_path)
                elif ext == '.pptx':
                    content = pptx_read(file_path)
                elif ext == '.rtf':
                    content = rtf_read(file_path)
                else:
                    # Handle unsupported file types here if needed
                    pass

                detected_words = []
                total_weight = 0
                for word, weight in words:
                    if str(word).casefold() in content.casefold():
                        detected_words.append(word)
                        total_weight += weight

                if detected_words:
                    if file_path in matched_files:
                        matched_files[file_path]['Detected Words'].extend(detected_words)
                        matched_files[file_path]['Total Weight'] += total_weight
                    else:
                        matched_files[file_path] = {'Detected Words': detected_words, 'Total Weight': total_weight,
                                                    'Extension': ext}
            elif ext in unsupported_extensions:
                office_files_count += 1
                other_office_files[file_path] = {
                    'Size': os.path.getsize(file_path),
                    'Extension': ext
                }

    return count, office_files_count


def generate_excel(threshold):
    wb = Workbook()

    matched_files_ws = wb.active
    matched_files_ws.title = "Matched_Files"
    matched_files_ws.append(['File_Path', 'Detected_Words', 'Total Words', 'Total Weight', 'Extension'])

    critical_ws = wb.create_sheet(title='Critical')
    critical_ws.append(['File_Path', 'Detected Words', 'Total Words', 'Total Weight', 'Extension'])

    unsupported_ws = wb.create_sheet(title='Unsupported_Files')
    unsupported_ws.append(['File_Path', 'Size', 'Extension', 'Error'])

    other_office_files_ws = wb.create_sheet(title='Other_office_files')
    other_office_files_ws.append(['File_Path', 'Size', 'Extension'])

    for file_path, data in matched_files.items():
        detected_words = data['Detected Words']
        total_weight = data['Total Weight']
        total_words = len(detected_words)
        extension = data['Extension']
        row_data = [file_path, ', '.join(map(str, detected_words)), total_words, total_weight, extension]
        matched_files_ws.append(row_data)
        if int(total_words) >= int(threshold):
            critical_ws.append(row_data)

    for file_path, data in unreadable_files.items():
        size = data['Size']
        extension = data['Extension']
        error = data['Error']
        row_data = [file_path, size, extension, error]
        unsupported_ws.append(row_data)

    for file_path, data in other_office_files.items():
        size = data['Size']
        extension = data['Extension']
        row_data = [file_path, size, extension]
        other_office_files_ws.append(row_data)

    return wb


def main():
    input_directory = sys.argv[1]
    keyword_file = sys.argv[2]
    threshold = sys.argv[3]
    output_directory = sys.argv[4]

    office_files_name = f"Office_files"
    matched_files_name = f"Matched"
    unsupported_files_name = f"Unsupported"
    other_office_files_name = f"Other_office_files"
    office_files_record_name = f"Office_files.xlsx"

    office_files_directory = os.path.join(output_directory, office_files_name)
    matched_files_directory = os.path.join(office_files_directory, matched_files_name)
    unsupported_files_directory = os.path.join(office_files_directory, unsupported_files_name)
    other_office_files_directory = os.path.join(office_files_directory, other_office_files_name)
    office_files_record_directory = os.path.join(office_files_directory, office_files_record_name)

    df = pd.read_excel(keyword_file)
    words = [(row['Keyword'], row['Weight']) for _, row in df.iterrows()]

    st.write("\n[-] Searching for Office files")
    count, office_files_count = search_office_files(input_directory, words)
    st.write("\n[+] Scanning complete")
    st.write("\n[+] Count of files scanned: \t", count)
    st.write('\n[+] Office files count: \t', office_files_count)

    os.makedirs(office_files_directory, exist_ok=True)
    os.makedirs(matched_files_directory, exist_ok=True)
    os.makedirs(unsupported_files_directory, exist_ok=True)
    os.makedirs(other_office_files_directory, exist_ok=True)
    st.write('\n[+] Created folders to save the output')

    st.write("\n[+] Creating record file in directory: \t", office_files_directory)
    wb = generate_excel(threshold)
    wb.save(office_files_record_directory)
    st.write('\n[+] Created record file: \t', office_files_record_directory)

    for file_path, info in matched_files.items():
        try:
            shutil.copy(file_path, os.path.join(matched_files_directory, os.path.basename(file_path)))
        except Exception as e:
            st.write("\n[-] Error: \t", str(e))
    for file_path, info in unreadable_files.items():
        try:
            shutil.copy(file_path, os.path.join(unsupported_files_directory, os.path.basename(file_path)))
        except Exception as e:
            st.write("\n[-] Error: \t", str(e))
    for file_path, info in other_office_files.items():
        try:
            shutil.copy(file_path, os.path.join(other_office_files_directory, os.path.basename(file_path)))
        except Exception as e:
            st.write("\n[-] Error: \t", str(e))

    st.write('\n[+] Files saved inside directory: \t', office_files_directory)

if __name__ == '__main__':
    main()