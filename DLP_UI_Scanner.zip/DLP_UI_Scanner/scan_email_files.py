import streamlit as st
from openpyxl import Workbook
import shutil
import sys
from email import policy
from email.parser import BytesParser
from email.header import decode_header
import mailbox
import eml_extractor
import email
from email.header import decode_header
from extract_msg import Message
import pandas as pd
import os

supported_extensions = ['.eml', '.msg', '.mbox']
other_email_extensions = ['.edb','.emlx','.ics','.oft','.olm','.ost','.p7s','.pst','.rpmsg','.tnef','.vcf']

matched_files = {}
unsupported_files = {}
other_email_files = {}

def extract_message_body(msg):
    message_body = ""
    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            content_disposition = str(part.get("Content-Disposition"))

            if "attachment" not in content_disposition:
                text = extract_text_from_part(part, content_type)
                if text:
                    message_body += text
    else:
        message_body += extract_text_from_part(msg, msg.get_content_type())

    return message_body

def extract_text_from_part(part, content_type):
    text = ""
    for charset in ['utf-8', 'latin-1']:
        try:
            if content_type == "text/plain" or content_type == "text/html":
                text = part.get_payload(decode=True).decode(charset)
            break  # Successfully decoded, no need to try other charsets
        except UnicodeDecodeError:
            pass

    return text

def mail_read(file_path):
    try:
        with open(file_path, 'rb') as msg_file:
            msg = email.message_from_binary_file(msg_file)
            message_body = extract_message_body(msg)
        return message_body
    except Exception as e:
        unsupported_files[file_path] = {
            'Size': os.path.getsize(file_path),
            'File Extension': os.path.splitext(file_path)[1].lower(),
            'Error': str(e)
        }

def search_email_files(input_directory, words):
    count = 0
    email_files_count = 0
    st.write("\n[+] Searching directory: \t", input_directory)
    for root, dir, files in os.walk(input_directory):
        for file in files:
            count += 1
            ext = os.path.splitext(file)[-1].lower()
            file_path = os.path.join(root, file)

            if ext in supported_extensions:
                email_files_count+=1
                content = mail_read(file_path)

                detected_words = []
                total_weight = 0

                for word, weight in words:
                    if str(word).casefold() in content.casefold():
                        detected_words.append(word)
                        total_weight += weight

                if detected_words:
                    if file_path in matched_files:
                        matched_files[file_path]['Detected Words'].extend(detected_words)
                        matched_files[file_path]['Total Weight'] += total_weight
                    else:
                        matched_files[file_path] = {'Detected Words': detected_words, 'Total Weight': total_weight,
                                                    'Extension': ext}                

            elif ext in other_email_extensions:
                email_files_count+=1
                other_email_files[file_path] = {
                    'Size': os.path.getsize(file_path),
                    'Extension': ext 
                }

    return count, email_files_count

def generate_excel(threshold):
    wb = Workbook()

    matched_files_ws = wb.active
    matched_files_ws.title = "Matched_Files"
    matched_files_ws.append(['File_Path', 'Detected_Words', 'Total Words', 'Total Weight', 'Extension'])

    critical_ws = wb.create_sheet(title='Critical')
    critical_ws.append(['File_Path', 'Detected Words', 'Total Words', 'Total Weight', 'Extension'])

    unsupported_ws = wb.create_sheet(title='Unsupported_Files')
    unsupported_ws.append(['File_Path', 'Size', 'Extension', 'Error'])

    other_email_files_ws = wb.create_sheet(title='Other_office_files')
    other_email_files_ws.append(['File_Path', 'Size', 'Extension'])

    for file_path, data in matched_files.items():
        detected_words = data['Detected Words']
        total_weight = data['Total Weight']
        total_words = len(detected_words)
        extension = data['Extension']
        row_data = [file_path, ', '.join(map(str, detected_words)), total_words, total_weight, extension]
        matched_files_ws.append(row_data)
        if int(total_words) >= int(threshold):
            critical_ws.append(row_data)

    for file_path, data in unsupported_files.items():
        size = data['Size']
        extension = data['Extension']
        error = data['Error']
        row_data = [file_path, size, extension, error]
        unsupported_ws.append(row_data)

    for file_path, data in other_email_files.items():
        size = data['Size']
        extension = data['Extension']
        row_data = [file_path, size, extension]
        other_email_files_ws.append(row_data)

    return wb 

def main():
    input_directory = sys.argv[1]
    keyword_file = sys.argv[2]
    threshold = sys.argv[3]
    output_directory = sys.argv[4]

    email_files_name = f"Email_files"
    matched_files_name = f"Matched_files"
    unsupported_files_name = f"Unsupported_files"
    other_email_files_name = f"Other_email_files"
    email_files_record_name = f"Email_files.xlsx"

    email_files_directory = os.path.join(output_directory, email_files_name)
    matched_files_directory = os.path.join(email_files_directory, matched_files_name)
    unsupported_files_directory = os.path.join(email_files_directory, unsupported_files_name)
    other_email_files_directory = os.path.join(email_files_directory, other_email_files_name)
    email_files_record_directory = os.path.join(email_files_directory, email_files_record_name)

    df = pd.read_excel(keyword_file)
    words = [(row['Keyword'], row['Weight']) for _, row in df.iterrows()]

    st.write("\n[-] Searching for Email files")
    count, email_files_count = search_email_files(input_directory, words)
    st.write("\n[+] Scanning complete")
    st.write("\n[+] Count of files scanned: \t", count)
    st.write('\n[+] Email files count: \t', email_files_count)

    os.makedirs(email_files_directory, exist_ok=True)
    os.makedirs(matched_files_directory, exist_ok=True)
    os.makedirs(unsupported_files_directory, exist_ok=True)
    os.makedirs(other_email_files_directory, exist_ok=True)
    st.write('\n[+] Created folders to save output')

    st.write("\n[+] Creating record file in directory: \t", email_files_directory)
    wb = generate_excel(threshold)
    wb.save(email_files_record_directory)
    st.write('\n[+] Created record file: \t', email_files_record_directory)

    for file_path, info in matched_files.items():
        try:
            shutil.copy(file_path, os.path.join(matched_files_directory, os.path.basename(file_path)))
        except Exception as e:
            st.write("\n[-] Error: \t", str(e))
    for file_path, info in unsupported_files.items():
        try:
            shutil.copy(file_path, os.path.join(unsupported_files_directory, os.path.basename(file_path)))
        except Exception as e:
            st.write("\n[-] Error: \t", str(e))
    for file_path, info in other_email_files.items():
        try:
            shutil.copy(file_path, os.path.join(other_email_files_directory, os.path.basename(file_path)))
        except Exception as e:
            st.write("\n[-] Error: \t", str(e))

    st.write('\n[+] Files saved inside directory: \t', email_files_directory)

if __name__ == '__main__':
    main()