import os 
from openpyxl import Workbook 
import shutil
import sys
import streamlit as st

image_files = {}
video_files = {}
error_files = {}

IMAGE_EXTENSIONS = [".ovr",".ndx",".ink",".hpgl",".hpg",".plt",".aic",".pict",".apm",".afdesign",".xar",".idea",".eps",".wmz",".wmf",".pct",".odg",".mp",".emz",".cmx",".ps",".emf",".fh4",".cdr",".svgz",".fcm",".ai",".svg",".vsd",".vsdx",".vstm",".sr2",".rwz",".orf",".mos",".mef",".mdc",".gpr",".eip",".crw",".arw",".cr3",".dcr",".dng",".fff",".raw",".rw2",".raf",".erf",".cr2",".nrw",".nef",".rwl",".ptx",".brt",".bm2",".bmf",".ais",".abm",".sid",".exr",".pic",".apx",".360",".sct",".xpm",".mpo",".jxr",".psb",".ppp",".pcx",".mng",".tif",".webp",".psp",".thm",".jfif",".heif",".jpx",".jpf",".jp2",".j2k",".gbr",".hdr",".cpc",".dib",".dicom",".ecw",".ct",".dcx",".clip",".cpt",".dcm",".agif",".apng",".avif",".bpg",".art",".tga",".png",".bmp",".heic",".jpg",".jpeg",".psd",".tiff",".sprite2",".bif",".djvu",".jxl",".dds",".gif",".icon",".wbc",".mnr",".mdl",".mdx",".u3d",".mdd",".mb",".max",".ma",".fbx",".dae",".bvh",".egg",".xpr",".skp",".dso",".ghx",".md5mesh",".mtl",".hipnc",".dwf",".3dm",".chr",".3ds",".shp",".obj",".gh",".mesh",".daz",".prc",".bbmodel",".md5anim",".crz"]
VIDEO_EXTENSIONS = [".flc",".ave",".avc",".avb",".av1",".av3",".3gpp",".asx",".scm",".inp",".lrv",".arf",".dav",".ifo",".exo",".mks",".avchd",".amv",".asf",".mpv",".nsv",".mxf",".pz",".m2ts",".mpe",".m4s",".mswmm",".f4v",".flv",".qt",".rm",".h265",".h264",".3g2",".m4v",".srt",".veg",".mp4",".mpg",".mpeg",".avi",".3gp",".vtt",".wlmp",".wmv",".aaf",".xvid",".m2v",".smil",".vro",".wrf",".bik",".vid",".sec",".prproj",".rmvb","0.264",".ssa",".ogv",".kine",".smi",".sub",".ts",".mov",".mts",".idx",".wpl",".sfd",".aep",".psv",".vob",".swf",".mkv",".webm"]

def search_multimedia(input_directory):
    for root, dirs, files in os.walk(input_directory):
        for file in files:
            ext = os.path.splitext(file)[-1].lower()
            file_path = os.path.join(root, file)
            if ext in IMAGE_EXTENSIONS:
                st.write('\n[+] Found Image file: ', file_path)
                image_files[file_path] = {
                    'Size': os.path.getsize(file_path),
                    'File Extension': ext,
                }
            if ext in VIDEO_EXTENSIONS:
                st.write('\n[+] Found Video file: ', file_path)
                video_files[file_path] = {
                    'Size': os.path.getsize(file_path),
                    'File Extension': ext,
                }

def generate_excel_file():
    wb = Workbook()

    # Results worksheet
    images_ws = wb.active
    images_ws.title = 'Image_Files'
    images_ws.append(['File_Path', 'Size', 'Extension'])

    videos_ws = wb.create_sheet(title='Video_Files')
    videos_ws.append(['File_Path', 'Size', 'Extension'])

    for file_path, data in image_files.items():
        file_size = data['Size']
        file_extension = data['File Extension']
        row_data = [file_path, file_size, file_extension]
        images_ws.append(row_data)

    for file_path, data in video_files.items():
        file_size = data['Size']
        file_extension = data['File Extension']
        row_data = [file_path, file_size, file_extension]
        videos_ws.append(row_data)

    return wb

def generate_error_files_record():
    wb = Workbook()

    error_ws = wb.active
    error_ws.title = "Error_Files"
    error_ws.append(["File_Path","Error"])

    for file_path, data in error_files.items():
        error = data['Error']
        row_data = [file_path, error]
        error_ws.append(row_data)
        
    return wb 

def main():
    input_directory = sys.argv[1]
    keyword_file = sys.argv[2]
    threshold = sys.argv[3]
    output_directory = sys.argv[4]

    multimedia_directory_name = f"Multimedia_Files"

    images_directory_name = f"Images"
    videos_directory_name = f"Videos"
    unsupported_files_name = f"Unsupported_files.xlsx"

    multimedia_directory = os.path.join(output_directory, multimedia_directory_name)

    images_directory = os.path.join(multimedia_directory, images_directory_name)
    videos_directory = os.path.join(multimedia_directory, videos_directory_name)
    unsupported_files_directory = os.path.join(multimedia_directory, unsupported_files_name)

    search_multimedia(input_directory)

    os.makedirs(images_directory, exist_ok=True)
    os.makedirs(videos_directory, exist_ok=True)

    output_file_name = f"Multimedia_Files.xlsx"
    output_file_directory = os.path.join(multimedia_directory, output_file_name)

    wb = generate_excel_file()
    wb.save(output_file_directory)

    st.write("\n[+] Excel file generated for Multimedia files")

    for file_path, info in image_files.items():
        try:
            shutil.copy(file_path, os.path.join(images_directory, os.path.basename(file_path)))
        except Exception as e:
            error_files[file_path] = {
                "Error" : str(e)
            }
    for file_path, info in video_files.items():
        try: 
            shutil.copy(file_path, os.path.join(videos_directory, os.path.basename(file_path)))
        except Exception as e:
            error_files[file_path] = {
                "Error" : str(e)
            }

    st.write("\n[+] Multimedia files copied to folder: \t", multimedia_directory)

    wb = generate_error_files_record()
    wb.save(unsupported_files_directory)

    st.write("\n[+] Record file generated for errors: \t", unsupported_files_directory)


if __name__ == '__main__':
    main()
