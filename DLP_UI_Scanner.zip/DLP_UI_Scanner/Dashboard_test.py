import streamlit as st
import subprocess

# Function to execute the selected operation
def execute_operation(operation, input_values):
    if all(input_values):  # Check if all input values are provided
        subprocess.run(["streamlit", "run", f"{operation}.py", *input_values])
        st.success(f"Executing {operation}...")
    else:
        st.warning("Please provide all required input values before executing the operation.")

# Main function
def main():
    # Initialize session_state if not exists
    if 'input_values' not in st.session_state:
        st.session_state.input_values = {}

    # Dashboard panel
    st.title("DLP Scanner")
    
    # Operations column
    with st.sidebar:
        st.subheader("Operations")
        # Operation options
        operations = {
            "Unpack files": "unpacker",
            "Extract Email attachments": "email_attachments_extractor",
            "Count files and file categories": "get_files_count",
            "Extract Embedded files": "embedded_files_extractor",
            "Copy Multimedia files": "copy_multimedia_files",
            "Scan PDF files": "scan_pdf_files",
            "Scan Office files": "scan_office_files",
            "Scan Email files": "scan_email_files",
            "Scan Other files": "scan_other_files",
        }
        selected_operation = st.selectbox("Select operation", list(operations.keys()))

    # User Input column
    with st.sidebar:
        st.subheader("User Input")
        input_directory = st.text_input("Enter directory to search")
        keyword_file = st.text_input("Enter keyword file path (.xlsx)")
        threshold = st.text_input("Enter threshold value")
        output_directory = st.text_input("Enter directory to save result")

    if selected_operation not in st.session_state.input_values:
        st.session_state.input_values[selected_operation] = [None] * 4

    # Button to trigger the selected operation
    execute_button = st.sidebar.button("Execute Operation")

    if execute_button:
        input_values = [input_directory, keyword_file, threshold, output_directory]
        st.session_state.input_values[selected_operation] = input_values
        execute_operation(operations[selected_operation], input_values)

if __name__ == '__main__':
    main()
