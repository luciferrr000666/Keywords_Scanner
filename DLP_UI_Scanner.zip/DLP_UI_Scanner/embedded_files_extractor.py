from AttachmentsExtractor import extractor
import streamlit as st
import os
import sys
from openpyxl import Workbook

# Embedded files record
embedded_files = {}
unsupported_files = {}

def extracted_embedded_files(file_path, destination_directory):
    try:
        os.makedirs(destination_directory, exist_ok=True)
        result = extractor.extract(file_path, destination_directory)
        if result == "True":
            st.write("\n[+] Saved embedded files from: \t", file_path)
            embedded_files[file_path] = {
                'Destination directory' : destination_directory,
                'Embedded_Files' : 'True'
            }
        else:
            st.write("\n[+] No embedded files found in: \t", file_path)
            embedded_files[file_path] = {
                'Destination directory' : destination_directory,
                'Embedded_Files' : "True"
            }
    except Exception as e:
        st.write("\n[-] Error", str(e))
        unsupported_files[file_path] = {
            'Error' : str(e)
        }
    
def search_files(input_directory):
    for root, dirs, files in os.walk(input_directory):
        for file in files:
            file_path = os.path.join(root, file)
            file_extension = os.path.splitext(file)[1].lower()

            destination_directory = os.path.splitext(file_path)[0]
            extracted_embedded_files(file_path, destination_directory)
            
def generate_excel():
    wb = Workbook()

    embedded_files_ws = wb.active

    embedded_files_ws.title = "Embedded Files"
    embedded_files_ws.append(['File_Path','Destination_directory', 'Embedded_Files'])

    unsupported_ws = wb.create_sheet(title="Unsupported Files")
    unsupported_ws.append(['File_Path','Error'])

    for file_path, d_d in embedded_files.items():
        d_directory = d_d['Destination directory']
        d_embed_files = d_d['Embedded_Files']
        if file_path:
            row_data = [file_path, d_directory, d_embed_files]
            embedded_files_ws.append(row_data)

    for file_path, d_d in unsupported_files.items():
        d_error = d_d['Error']
        if file_path:
            row_data = [file_path, d_error]
            unsupported_ws.append(row_data)

    return wb

def main():

    input_directory = sys.argv[1]
    keyword_file = sys.argv[2]
    threshold = sys.argv[3]
    output_directory = sys.argv[4]

    if os.path.isdir(input_directory):
        search_files(input_directory)
        st.write('\n[+] Extraction complete')
    else:
        st.write('\n[-] Invalid path provided')

    output_file_name = f"Embedded_Files_Record.xlsx"

    output_file_directory = os.path.join(output_directory,output_file_name)

    st.write("\n[+] Creating excel")

    wb = generate_excel()
    wb.save(output_file_directory)
    st.write('\n[+] Record saved', output_file_directory)

if __name__ == '__main__':
    main()
    