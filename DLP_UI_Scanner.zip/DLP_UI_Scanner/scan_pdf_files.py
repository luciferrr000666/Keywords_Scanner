import os
import shutil
import sys
from openpyxl import Workbook
from PyPDF2 import PdfReader
import streamlit as st
import pandas as pd

pdf_files = {}
unsupported_files = {}

def pdf_read(file_path):
    try:
        st.write("\n[-] Reading PDF file: \t", file_path)
        reader = PdfReader(file_path, strict=False)
        content = ''
        for i in range(len(reader.pages)):
            page = reader.pages[i]
            text = page.extract_text()
            content += text
        return content
    except Exception as e:
        st.write("\n[-] Error reading PDF file: \t", file_path)
        st.write("\n[-] Error details: \t", str(e))
        return ''

def search_pdf(input_directory, words):
    st.write("\n[+] Searching directory: \t", input_directory)
    for root, dir, files in os.walk(input_directory):
        for file in files:
            ext = os.path.splitext(file)[-1].lower()
            file_path = os.path.join(root, file)
            if ext == '.pdf':
                content = pdf_read(file_path)
                detected_words = []
                total_weight = 0
                for word, weight in words:
                    if str(word).casefold() in content.casefold():
                        detected_words.append(word)
                        total_weight += weight
                if detected_words:
                    if file_path in pdf_files:
                        pdf_files[file_path]['Detected Words'].extend(detected_words)
                        pdf_files[file_path]['Total Weight'] += total_weight
                    else:
                        pdf_files[file_path] = {'Detected Words': detected_words, 'Total Weight': total_weight}
                else:
                    unsupported_files[file_path] = {
                        'Size': os.path.getsize(file_path),
                        'Error': 'No matching keywords found in the PDF.'
                    }

def generate_excel(threshold):
    wb = Workbook()

    pdf_files_ws = wb.active
    pdf_files_ws.title = 'PDF_Files'
    pdf_files_ws.append(['File_Path', 'Detected_Words', 'Total Words', 'Total Weight'])

    critical_ws = wb.create_sheet(title='Critical')
    critical_ws.append(['File_Path', 'Detected Words', 'Total Words', 'Total Weight'])

    unsupported_ws = wb.create_sheet(title='Unsupported_Files')
    unsupported_ws.append(['File_Path', 'Size', 'Error'])

    for file_path, data in pdf_files.items():
        detected_words = data['Detected Words']
        total_weight = data['Total Weight']
        total_words = len(detected_words)
        row_data = [file_path, ', '.join(map(str, detected_words)), total_words, total_weight]
        pdf_files_ws.append(row_data)
        if int(total_words) >= int(threshold):
            critical_ws.append(row_data)

    for file_path, data in unsupported_files.items():
        size = data['Size']
        error = data['Error']
        row_data = [file_path, size, error]
        unsupported_ws.append(row_data)

    return wb 

def main():
    input_directory = sys.argv[1]
    keyword_file = sys.argv[2]
    threshold = sys.argv[3]
    output_directory = sys.argv[4]

    pdf_files_name = f"PDF_Files"
    matched_files_name = f"Matched"
    unsupported_files_name = f"Unsupported"
    pdf_files_record_xlsx = f"PDF_Files.xlsx"

    pdf_files_directory = os.path.join(output_directory, pdf_files_name)
    matched_files_directory = os.path.join(pdf_files_directory, matched_files_name)
    pdf_files_record_directory = os.path.join(pdf_files_directory, pdf_files_record_xlsx)
    unsupported_files_directory = os.path.join(pdf_files_directory, unsupported_files_name)

    df = pd.read_excel(keyword_file)
    words = [(row['Keyword'], row['Weight']) for _, row in df.iterrows()]

    st.write("\n[-] Searching for PDF files")
    search_pdf(input_directory, words)
    st.write("\n[+] Scanning complete")

    os.makedirs(pdf_files_directory, exist_ok=True)
    os.makedirs(matched_files_directory, exist_ok=True)
    os.makedirs(unsupported_files_directory, exist_ok=True)

    st.write("\n[+] Creating record file in directory: \t", pdf_files_directory)
    wb = generate_excel(threshold)
    wb.save(pdf_files_record_directory)
    st.write("\n[+] Created record file: \t", pdf_files_record_directory)

    st.write("\n[+] Copying the matched and unsupported PDF files")
    for file_path, info in pdf_files.items():
        try:
            shutil.copy(file_path, os.path.join(matched_files_directory, os.path.basename(file_path)))
        except Exception as e:
            st.write("\n[-] Error: \t", str(e))
    for file_path, info in unsupported_files.items():
        try:
            shutil.copy(file_path, os.path.join(unsupported_files_directory, os.path.basename(file_path)))
        except Exception as e:
            st.write("\n[-] Error: \t", str(e))

    st.write("\n[+] Files saved inside directory: \t", pdf_files_directory)

if __name__ == '__main__':
    main()
