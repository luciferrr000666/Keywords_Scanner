import os
import concurrent.futures
from collections import Counter
import argparse
import streamlit as st
import sys

def count_files_by_extension(directory):
    file_count = 0
    file_types = {}

    for root, dirs, files in os.walk(directory):
        for file in files:
            file_count += 1
            ext = os.path.splitext(file)[-1].lower()
            if ext in file_types:
                file_types[ext] += 1
            else:
                file_types[ext] = 1

    st.write("No. of files within ", directory, " : ", file_count)
    for ext, count in file_types.items():
        if ext == "":
            st.write("\nUndetermined: \t", count)
        else:
            st.write("\n", ext, ": \t", count, " files")

def main():
    st.title("Count Files and Categories")
    st.subheader("Operations")
    
    input_directory = sys.argv[1]
    keyword_file = sys.argv[2]
    threshold = sys.argv[3]
    output_directory = sys.argv[4]
    
    if os.path.isdir(input_directory):
        count_files_by_extension(input_directory)
    else:
        st.write("\nInvalid path")

if __name__ == '__main__':
    main()
