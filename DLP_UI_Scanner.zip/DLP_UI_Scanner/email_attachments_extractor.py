import re
from email import policy
from email.parser import BytesParser
import pandas as pd
import os
import time
from collections import Counter
import streamlit as st
from openpyxl import Workbook
import sys

email_attachments_extracted = {}
unsupported_emails = {}

def directory_walk(directory):
    for root, dirs, files in os.walk(directory):
        for file_name in files:
            if file_name.lower().endswith((".eml", ".msg", ".mbox")):
                file_path = os.path.join(root, file_name)
                try:
                    attachments_directory = os.path.join(root, "EmailAttachments")
                    os.makedirs(attachments_directory, exist_ok=True)
                    counts = extract_attachments(file_path, attachments_directory)
                    if counts['attachments'] > 0:
                        st.write(f"[+] Attachments saved for file {file_path} inside directory {attachments_directory}")
                    else:
                        st.write(f"[+] No attachments found in {file_path}")
                        directory_walk(attachments_directory)
                except Exception as e:
                    st.write(f"[-] Error while processing file {file_path}: {str(e)}")
                    unsupported_emails[file_path] = {
                        "Error" : str(e)
                    }
                    continue
    
def extract_attachments(email_file, attachments_directory):
    with open(email_file, 'rb') as file:
        msg = BytesParser(policy=policy.default).parse(file)
        
    for part in msg.iter_attachments():
        filename = part.get_filename()
        if filename: 
            st.write(f"[+] Found attachment for {email_file}: {filename}")
            attachment_path = os.path.join(attachments_directory, filename)
            with open(attachment_path, 'wb') as attachment_file:
                attachment_file.write(part.get_payload(decode=True))
            email_attachments_extracted[email_file] = {
                "Attachment" : "True",
                }
        else:
            email_attachments_extracted[email_file] = {
                "Attachment" : "False"
            }
    
def generate_excel():
    wb = Workbook()

    email_attachment_files_ws = wb.active

    email_attachment_files_ws.title = "Attachment Files"
    email_attachment_files_ws.append(['File_Path', 'Attachment'])

    unsupported_ws = wb.create_sheet(title="Unsupported Files")
    unsupported_ws.append(['File_Path','Error'])

    for file_path, d_d in email_attachments_extracted.items():
        d_embed_files = d_d['Attachment']
        if file_path:
            row_data = [file_path, d_embed_files]
            email_attachment_files_ws.append(row_data)

    for file_path, d_d in unsupported_emails.items():
        d_error = d_d['Error']
        if file_path:
            row_data = [file_path, d_error]
            unsupported_ws.append(row_data)

    return wb

def main():
    st.title("Extracting E-Mail Attachments")
    st.subheader("Search Directory")

    input_directory = sys.argv[1]
    keyword_file = sys.argv[2]
    threshold = sys.argv[3]
    output_directory = sys.argv[4]

    if os.path.isdir(input_directory):
        st.write(f"[+] {input_directory}")
        directory_walk(input_directory)
        st.write(f"[+] Extraction completed")
    else:
        st.write("[-] Invalid path provided")

    st.write("\n[+] Creating excel")

    output_file_name = f"Email_attachments_extracted.xlsx"

    output_file_directory = os.path.join(output_directory, output_file_name)

    wb = generate_excel()
    wb.save(output_file_directory)
    st.write('\n[+] Record saved', output_file_directory)

if __name__ == '__main__':
    main()
